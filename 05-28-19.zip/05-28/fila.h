#include <stdio.h>
#include <stdlib.h>

typedef struct fila Fila;

Fila* criaFila();

void insere(Fila *f, float valor);

float remova(Fila *f);

int filaVazia(Fila *f);

void libera(Fila *f);


