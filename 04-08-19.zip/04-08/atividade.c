#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "ponto.h"

int main() {
    Ponto* p1;
    Ponto* p2;
    float i = 0;
    float x;
    float y;


    p1 = cria(5,5);
    p2 = cria(3,3);

    /*
    Calcular a distancia

    i = distancia(p1, p2);
    printf("A distancia entre os dois pontos e %f\n", i);
    */

    /*
    Mostrar coordenadas
    */

    atribui(p1, 4, 3);

    acessa(p1, &x, &y);
    printf("\nO ponto esta nas coordenadas %f e %f.\n", x,y);

    return 0;
}
