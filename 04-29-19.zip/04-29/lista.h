typedef struct lista Lista;

/*Cria uma lista vazia*/
Lista* criaLista();

/*Insere um elemento na lista*/
Lista* insere(Lista* l, int i);

/*Percorre os elementos da lista*/
void imprime(Lista* l);

/*Verifica se a lista esta vazia*/
int vazia(Lista* l);

/*Busca por um elemento na lista*/
Lista* busca(Lista* l, int i);

/*Remove um elemento da lista*/
Lista* remova(Lista* l, int v);

/*Libera a memoria da lista*/
void libera(Lista* l);
