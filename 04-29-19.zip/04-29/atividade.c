#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lista.h"

int main(){

    Lista* minhaLista = criaLista();

    minhaLista = insere(minhaLista, 4);
    minhaLista = insere(minhaLista, 3);
    minhaLista = insere(minhaLista, 2);
    minhaLista = insere(minhaLista, 1);

    minhaLista = remova(minhaLista, 3);

    imprime(minhaLista);

    return 0;
}
