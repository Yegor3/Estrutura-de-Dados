#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lista.h"

struct lista{
    int info;
    struct lista* prox;
};

Lista* criaLista(){
    return NULL;
}

Lista* insere(Lista* l, int i){
    Lista* novo = (Lista*) malloc(sizeof(Lista));
    novo->info = i;
    novo->prox = l;
    return novo;
}

void imprime(Lista* l){
    Lista* p;
    for(p = l; p != NULL; p = p->prox){
        printf("info = %i\n", p->info);
    }
}

int vazia(Lista* l){
    return(l == NULL);
}


Lista* busca(Lista* l, int i){
    Lista* p;
    for(p = l; p != NULL; p = p->prox){
        if(p->info == i)
            return p;
    }
    return NULL;
}

Lista* remova(Lista* l, int v){
    Lista *ant = NULL;
    Lista* p = l;

    while(p != NULL && p->info != v){
        ant = p;
        p = p->prox;
    }

    if(p == NULL){
        return l;
    } else if(ant == NULL){
        l = p->prox;
    } else {
        ant->prox = p->prox;
    }

    free(p);
    return l;
}

void libera(Lista* l){
    Lista* p = l;
    while(p != NULL){
        Lista* t = p->prox;
        free(p);
        p = t;
    }
}








