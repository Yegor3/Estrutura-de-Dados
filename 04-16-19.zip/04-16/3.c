#include <stdio.h>
#include <stdlib.h>

//fatorial recursivo
int fat(int n){
	if ((n == 0)||(n == 1))
		return 1;
	else
		return n * fat(n-1);
}

//Versão recursiva de expo
int expoR(int n){
	if (n == 0)
		return 1;
	else{
		return 2 * expoR(n-1);
	}
}

//Versão recursiva de "tamanho"
int tamanhoR(char s[]){
	 if (s[0] == '\0')
	 	return 0;
	 else{
	 	return 1 + tamanhoR(s + 1);
	 }
}

//Versão recursiva de "contaLetra"
int contaLetraR(char s[], char letra){
	if (s[0] == '\0')
	 	return 0;
	else{
	 	if (s[0] == letra)
	 		return 1 + contaLetraR(s + 1, letra);
	 	else
	 		return 0 + contaLetraR(s + 1, letra);
	}
}

//Imprime os elementos da string de forma recursiva
void imprimeR(char s[]){
	if (s[0] != '\0'){
		printf("%c",s[0]);
		imprimeR(s+1);
	}
}

//Versão recursiva de "reverso2"
void reversoR(char s[]){
	if (s[0] != '\0'){
		reversoR(s+1);
		printf("%c",s[0]);
	}
}


//Versão recursiva de "somaSerie"
float somaSerieR(int n){
	if (n == 1)
		return 1;
	else
		return 1.0/fat(n) + somaSerieR(n-1);
}

//Versão recursiva de "somatorio"
int somatorioR(int n){
	if (n == 1)
		return 1;
	else
		return n*n + somatorioR(n-1);
}

//Versão recursiva de "somaVetor"
//soma os elementos do primeiro ao úlltimo
int somaVetorR(int v[],int n){
	if (n == 0)
		return 0;
	else
		return v[0] + somaVetorR(v+1,n-1);
}

//Calcula a soma dos elementos de um vetor de forma recursiva
//soma os elementos do último ao primeiro
float somaV(float v[],int tam){
	if(tam == 1)
		return v[0];
	else
		return v[tam-1] + somaV(v,tam-1);

}

int main(){

    int i = 0;
    /*char nome[] = "Igor Marques Aguiar";*/

    i = expoR(5);
    printf("%i\n", i);
	return 0;
}
