#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct pilha Pilha;

/*Cria uma pilha vazia*/
Pilha* criaPilha();

/*Insere um elemento na pilha*/
void push(Pilha* p, float valor);

/*Remove um elemento da lista*/
void pop(Pilha* p);

/*Verifica se a pilha está vazia*/
int pilhaVazia(Pilha* p);

/*Libera a memoria da pilha*/
void pilhaLibera(Pilha* p);

float topo(Pilha* p);

void concatenaPilha(Pilha* p1, Pilha* p2){
