#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pilha.h"
#define TAM 50

struct pilha{
    int qtdItens;
    float vet[TAM];
};

Pilha* criaPilha(){
    Pilha* p = (Pilha* ) malloc(sizeof(Pilha));
    p->qtdItens = 0;
    return p;
}

void push(Pilha* p, float valor){
    if(p->qtdItens == TAM){
        exit(1);
    }
    p->vet[p->qtdItens] = valor;
    p->qtdItens++;
}

void pop(Pilha* p){
    float topo;
    if(pilhaVazia(p)){
        exit(1);    
    }
    topo = p->vet[p->qtdItens - 1];
    p->qtdItens--;
}

int pilhaVazia(Pilha* p){
    return(p->qtdItens == 0);
}

void pilhaLibera(Pilha* p){
    free(p);
}

float topo(Pilha* p){
    float top;
    if(pilhaVazia(p)){
        exit(1);    
    }
    topo = p->vet[p->qtdItens - 1];
    return top;
}

void concatenaPilha(Pilha* p1, Pilha* p2){
    int i = 0;

    if(pilhaVazia(p1) || pilhaVazia(p2)){
        exit(1);
    }

    while(!pilhaVazia(p2)){
        push(p1, p2->tam[qtdItens]);
        pop(p2);
    }
}
















